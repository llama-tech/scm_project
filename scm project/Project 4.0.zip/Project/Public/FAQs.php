<html>
<head>
<link rel="icon" href="images/favicon.png" type="image/png" />
</head>
<body background="images/background.jpg">
<?php # Script 3.5 - index.php
$page_title = 'Home Page';
include ('./includes/header.php');
?>
<table class="table table-bordered" >
  <tr>
	<th><h2 style="font-weight: 700;"><center>FAQS</center><h2></th>
  </tr>
 <tr>
	<th><br><center><h4 style="font-weight: 600;">Return</h4><br><h4>All sales are final. No exchanges or refunds.</h4></center></th>
</tr>

  <tr>
	<th><center><br><h4 style="font-weight: 600;">Shipping?</h4> <br>
	<h4>Orders delivered to all destinations.International buyer will be charged postal fees <br>
		accordingly. Please select your country during checkout to find the postal fees imposed.<br>
		Packages shipped to Malaysian address will arrive in 1-3 business days. For international packages, estimated delivery times will be in 7 business days. <br>
		You will receive a e-mail with tracking number once your order has been shipped.</h4></center> </th>
 </tr>



</table>

</body>
</html>
