<html>
<head>
<link rel="icon" href="images/favicon.png" type="image/png" />
</head>
<body background="images/b.png">
<?php # Script 3.5 - index.php
$page_title = 'Home Page';
include ('./includes/header.php');
?>
<br />
<center><img width="10%" src="images/llamaplug.png" /> </center>
<br />
<table class="table table-bordered" >
  <tr>
	<th><h2 style="font-weight: 700;"><center>About Us</center><h2></th>

  </tr>

 <tr>
	<th><br><center><h4>The world famous urban sneakers of all time.<br> We aim to bring you selected exotic & hard-to-get goodies from around the world to your doorstep.  </h4> </center></th>
 </tr>
</table>

</body>
</html>
