<?php
require ('db.php');
$order_id = $_GET['order_id'];
$product_id = $_GET['product_id'];
$size = $_GET['size'];


$sql = "DELETE FROM orders WHERE order_id='$order_id'";
$statement = $connection->prepare($sql);

	if ($statement->execute([':order_id' => $order_id])) {
	//session_start();
//$sneaker_id =$_SESSION["sneaker_id"] ;

	  	$sql = "SELECT quantity FROM quantity_size WHERE product_id=:product_id AND size=:size";
	$statement = $connection->prepare($sql);
$statement->execute([':product_id' => $product_id ,':size' => $size ]);
$Listquan = $statement->fetch(PDO::FETCH_OBJ);
	
	$quantity = $Listquan->quantity + 1 ;
	
	
	
	//$quantity =  ($_SESSION["quantity"])+1; 
	
	$sql2 = "UPDATE quantity_size SET  quantity= :quantity  WHERE product_id=:product_id AND size=:size";
	
  $statement = $connection->prepare($sql2);
    if ($statement->execute([':quantity' => $quantity,':product_id' => $product_id ,':size' => $size ])) {
	header("Location: /project/Member/MemberCheckOut.php");
	}
}

?>